# Find Assult > 2023-07-28 4:17pm
https://universe.roboflow.com/project-vpl7k/find-assult

Provided by a Roboflow user
License: CC BY 4.0

